# UK Culture & Etiquette

- Queuing is very important; always wait your turn.
- People value politeness: say “please,” “thank you,” and “sorry.”
- Personal space is respected; avoid standing too close.
- Tipping is optional but appreciated (10–12% in restaurants if not included).
- Keep voices low in public transport and indoor spaces.
- Pubs often require ordering at the bar, not at the table.
- Dress is generally casual, but smart-casual is common in cities.
