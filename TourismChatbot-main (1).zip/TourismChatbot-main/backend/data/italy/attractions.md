# UK Attractions

## London
- Big Ben, Westminster Abbey, Buckingham Palace
- British Museum, Tate Modern

## Edinburgh
- Edinburgh Castle, Royal Mile, Arthur’s Seat

## Manchester
- Football stadium tours, Northern Quarter

## Bath
- Roman Baths, Georgian architecture
